﻿Public Class Form1
    Dim num As Integer
    Private Sub btn_openForm2_Click(sender As Object, e As EventArgs) Handles btn_openForm2.Click

        Form2.Show()
    End Sub

End Class

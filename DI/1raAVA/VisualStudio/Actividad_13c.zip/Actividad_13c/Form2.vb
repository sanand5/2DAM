﻿Public Class Form2
    Private Sub btn_bgcolor_Click(sender As Object, e As EventArgs) Handles btn_bgcolor.Click
        Close()
    End Sub
End Class
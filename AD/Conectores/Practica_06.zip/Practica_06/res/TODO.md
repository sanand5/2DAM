## Errores
![Alt text](image.png)

## TODO codigo
- [x] Insertar Alumno
- [ ] Gestionar lode no usar objetos
- [x] Eliminar Alumno
  - [x] Matricular Alumno
    - [x] Encontrar Alumno
    - [x] Encontrar Modulo (por nombre)
      - [x] Hacer que no pueden haver varios modulos con el mismo nombre
  - [x] Eliminar Matricula
- [x] Insertar Modulo
- [x] Eliminar Modulo
  - [x] Eliminar Matriculas con el Modulo
- [x] Añadir notas a Aluumno en un modulo
  - [x] Matricular Alumno
  - [x] Insertar Modulo
- [x] Modificar Notas
- [x] Añadir notas
- [x] PedirID Matrcula
- [ ] IMPORTAR/EXPORTAR
  - [x] Importar DB
  - [x] Exportar DB
  - [ ] gestionar si el nia esta repetido
  - [ ] preguntar al usuario
  - [ ] Gestionar que no se conecte cada vez
- [ ] Crear tablas si no las encuentra
  - [x] crear funcion para crear las tablas
- [ ] Ordenar codigo
  - [ ] gestionar private, public, protected
  - [ ] Mensajes de error
- [ ] Clase menu
- [ ] mostrar notas de alumnos
- [ ] gestionar si la contraseña esta mal puesta

## TODO menu
Menu
- [ ] (0) Salir
- [ ] (1) Menu Alumnos
- [ ] (2) Menu Modulos
- [ ] (3) Evaluar
- [ ] (4) Importar
- [ ] (5) Exportar

Menu Alumno
- [x] (0) Salir
- [x] (1) Alta
- [x] (2) Baja
- [x] (3) Listar

Menu Modulo
- [ ] (0) Salir
- [ ] (1) Alta
- [ ] (2) Baja
- [ ] (3) Listar
- [ ] (4) Matricular Alumno

Menu Evaluar
- [ ] (0) Salir
- [ ] (1) Qualificar
- [ ] (2) Modificar
- [ ] (3) Mostrar Notas de un Modulo
- [ ] (4) Mostrar Notas de un Alumno
- [ ] (5) Mostrar Notas del Centro


## TODO today
1. - [x] Crear una base de datos POSTGRESQL*
2. - [x] Conectarme a ella con pgAdmin*
3. - [x] Conectarme desde mi programa*
4. - [x] Conseguir crear las tablas desde el programa*
5. - [x] Modificar los nombres de las columnas en la DB mysql*
6. - [x] Memoria Base
7. - [ ] TODO programa 
8. - [ ] Juntar el programa
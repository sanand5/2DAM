## Errores
![Alt text](image.png)

## TODO codigo
- [x] INSERTAR
  - [x] Alumno
  - [x] Modulo
    - [x] Hacer que no pueden haver varios modulos con el mismo nombre
  - [x] Matricula
- [x] ELIMINAR
  - [x] Alumno
  - [x] Modulo
  - [x] Matricula
- [x] Gestionar lode no usar objetos
- [x] ![Alt text](image.png)
- [x] Matricular Alumno
  - [x] Encontrar Alumno
  - [x] Encontrar Modulo (por nombre)
  - [x] Eliminar Matriculas con el Modulo
- [x] Añadir notas a Aluumno en un modulo
- [x] Modificar Notas
- [x] Añadir notas
- [x] PedirID Matrcula
- [ ] IMPORTAR/EXPORTAR
  - [x] Importar DB
  - [x] Exportar DB
- [x] Crear tablas si no las encuentra
  - [x] crear funcion para crear las tablas
- [x] Clase menu
- [x] mostrar notas de alumnos
- [x] gestionar si la contraseña esta mal puesta
- [x] gestionar fecha
- [x] sustituir *
- [x] Create TAble, crear una funcion en gestor para hacer-lo, parametros: tablename, querymysql, querypostgre
- [x] MENSAJES
  - [x] Error
  - [x] OK
    - [X] Importar/Exportar
    - [x] Menu Alumnos
      - [x] Alta
      - [x] Baja
    - [x] Menu Modulos
      - [x] Alta
      - [x] Baja
    - [x] Menu Matriculas
  - [x] Warning
- [ ] IMPORTAR/EXPORTAR
  - [ ] gestionar si el nia esta repetido
  - [ ] preguntar al usuario
- [ ] Ordenar codigo
  - [x] gestionar private, public, protected
- [x] desmatricular alumnos

## Error

# Memoria Practica VI, Components i Conectors

## Que 
<div style="text-align: justify;">
Modifica el programa anterior para que, utlitzant varis connectors, puga almacenar l'informació a diverses Base de Dades

## Para que

Este ejercicio ha resultado útil para aprender y practicar el funcionamiento de los conectores. También ha sido beneficioso para adquirir conocimientos sobre bases de datos, ya que fue necesario ejecutar varias consultas. En mi experiencia, la dificultad de este programa reside en las consultas i la gestion de poderse conectar a otras bases de datos ademas de  la variabilidad en la sintaxis SQL entre distintas bases de datos. En resumen, la actividad fue útil para comprender mejor el funcionamiento de conectores, así como para aprender a realizar consultas, entre otros aspectos.

## Pseudocodigo
### Conexion
    ```
    Enumeración DatabaseType:
        MYSQL
        POSTGRESQL

    Clase Conexion:
        
        Constante URL: "jdbc:mysql://localhost/"
        Constante DB: "10813358"
        Constante USER: "10813358"
        Constante PASSWORD: "10813358"
        Variable `con` inicializada a nulo

        Función getConnection:
            Intentar:
                con -> Llamar a DriverManager.getConnection concatenando URL, DB, USER y PASSWORD
            Capturar SQLException:
                Mensaje de error
            Devolver con

        Función getDataBaseType:
            Variable databasetype inicializada a nulo
            Si URL contiene "postgresql":
                databasetype -> POSTGRESQL
            Sino, si URL contiene "mysql":
                databasetype -> MYSQL
            Devolver databasetype
    ```
### gestor
    ```
    Clase gestor:
        Crear una instancia de ReadClient llamada rc
        Crear una instancia de Conexion llamada conexion

        Función testConexion:
            Intentar:
                connection = Llamar a getConnection desde la instancia de conexion
                Si connection no es nulo y no está cerrado:
                    Llamar a Colors.okMsg con el mensaje "¡Conexión exitosa!"
                    Devolver verdadero
                Sino:
                    Llamar a Colors.errMsg con el mensaje "La conexión está cerrada o es nula."
            Capturar SQLException:
                Mensaje de error
            Devolver falso

        Función executeUpdate con parámetro query:
            Intentar:
                connection = Llamar a getConnection desde la instancia de conexion
                Si connection no es nulo:
                    Intentar:
                        statement = Crear un PreparedStatement con la query y la conexión
                        Llamar a statement.executeUpdate
                    Capturar SQLException:
                        Mensaje de error
                Sino:
                    Mensaje de error
            Capturar SQLException:
                Mensaje de error

        Función select con parámetros select, from, where, returnType y params:
            Crear la query concatenando "SELECT ", select, " FROM ", from, " WHERE ", where
            Inicializar result a nulo

            Intentar:
                rs ← Llamar a executeSelect con la query y los parámetros
                Si rs.next():
                    Si returnType es Integer:
                        Asignar a result el valor casteado de rs.getInt(1)
                    Sino, si returnType es String:
                        Asignar a result el valor casteado de rs.getString(1)
            Capturar SQLException:
                Imprimir el stack trace
            Devolver result

        Función executeSelect con parámetros query y params:
            Intentar:
                connection ← Llamar a getConnection desde la instancia de conexion
                Si connection no es nulo:
                    Intentar:
                        statement ← Crear un PreparedStatement con la query y la conexión
                        Por cada parámetro en params:
                            Llamar a statement.setObject con el índice y el parámetro
                        Devolver statement.executeQuery
                    Capturar SQLException:
                        Llamar a Colors.errMsg con el mensaje "Imposible hacer la consulta"
            Capturar SQLException:
                Llamar a Colors.errMsg con el mensaje "Error inesperado"
            Devolver nulo

        Función createTable con parámetros tableName, queryMYSQL y queryPOSTGRESQL:
            Obtener el tipo de base de datos desde la instancia de Conexion
            Si la tabla no existe:
                Llamar a Colors.debMsg con el mensaje "Tabla " + tableName + " creada."
                Inicializar createTableQuery a cadena vacía

                Si el tipo de base de datos es MYSQL:
                    Asignar a createTableQuery el valor de queryMYSQL formateado con tableName
                Sino, si el tipo de base de datos es POSTGRESQL:
                    Asignar a createTableQuery el valor de queryPOST
                    Asignar a createTableQuery el valor de queryPOSTGRESQL
                Llamar a executeUpdate con createTableQuery

        Función getTitulo con parámetro tableName:
            Crear titulo con el formato "##### LISTA DE %s EN DB : %s #####%n", tableName en mayúsculas y Conexion.DB
            Crear subrallado como cadena vacía
            Desde i=2 hasta la longitud de titulo-1:
                Concatenar "#" a subrallado
            Devolver concatenación de titulo y subrallado

        Función write con parámetros path y datos:
            Intentar:
                Crear un objeto File con path
                Si el archivo existe, borrarlo
                Sino, crear un nuevo archivo
                Intentar:
                    Crear un BufferedWriter con un FileWriter asociado al archivo
                    Escribir los datos en el archivo
                    Llamar a Colors.okMsg con el mensaje "Datos escritos con éxito en el archivo: " + path
                Capturar IOException:
                    Llamar a Colors.errMsg con el mensaje "No se ha podido escribir en el archivo: " + path
            Capturar IOException:
                Llamar a Colors.errMsg con el mensaje "Error inesperado"

        Función read con parámetro path:
            Crear una lista de cadenas llamada lines

            Intentar:
                Crear un objeto File con path
                Si el archivo no existe:
                    Llamar a Colors.errMsg con el mensaje "El archivo no existe: " + path
                    Devolver la lista de líneas
                Intentar:
                    Crear un BufferedReader con un FileReader asociado al archivo
                    Leer cada línea del archivo y añadirla a la lista de líneas
            Capturar IOException:
                Llamar a Colors.errMsg con el mensaje "El archivo no se ha podido leer: " + path
            Capturar IOException:
                Llamar a Colors.errMsg con el mensaje "Error inesperado"
            Devolver la lista de líneas

        Función tableExists con parámetro tableName:
            Obtener el tipo de base de datos desde la instancia de Conexion
            Si el tipo de base de datos es nulo:
                Llamar a Colors.errMsg con el mensaje "Tipo de base de datos no compatible."
                Devolver falso
            Sino:
                Crear query según el tipo de base de datos

                Intentar:
                    Ejecutar la query con executeSelect
                    Obtener el resultado del conteo de tablas
                    Devolver verdadero si el resultado es mayor a 0, sino falso
                Capturar SQLException:
                    Llamar a Colors.errMsg con el mensaje "Error en la ejecución."
                    Devolver falso
    ```
### gsAlumnos
    ```

    ```
### gsModulos
    ```

    ```
### gsMatriculas
    ```

    ```
### menus
    ```

    ```
### Practica_06
    ```

    ```

## Como
### Conexion
### gestor
### gsAlumnos
### gsModulos
### gsMatriculas
### menus
### Practica_06

## Conclusión
En conclusión, considero que esta actividad ha sido interesante y ha contribuido significativamente a mejorar mis habilidades de programación con conectores y bases de datos. El uso de nuevas funciones para acceder y modificar la base de datos desde mi programa ha ampliado mi comprensión y destrezas en este ámbito. A lo largo de la actividad, he descubierto algunas funciones que no conocía como la ``enumeración anidada`` en java.

La práctica de diferentes consultas ha sido beneficiosa y ha reforzado mi conocimiento en el manejo de bases de datos. Además, me intriga conocer las diferentes aproximaciones que mis compañeros han tomado para abordar esta actividad, ya que estoy consciente de que hay varias formas de implementarla. Consultar a mis amigos y obtener explicaciones sobre sus enfoques podría proporcionarme valiosas perspectivas y aprender nuevas técnicas.

En general, aunque la actividad fue fácil de entender conceptualmente, la implementación resultó ser desafiante debido a su extensión, la posibilidad de errores y la gestion de diferentes bases de datos. Sin embargo, estoy satisfecho con los resultados obtenidos y considero que la dificultad fue proporcional al aprendizaje adquirido.

</div>

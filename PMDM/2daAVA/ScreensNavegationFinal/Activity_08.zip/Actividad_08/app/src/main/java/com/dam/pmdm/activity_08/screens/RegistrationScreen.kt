package com.dam.pmdm.activity_08.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox

import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.dam.pmdm.activity_08.R
import com.dam.pmdm.activity_08.navigation.AppScreens

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegistrationScreen(navController: NavController, paramText: String?): Unit {
    Scaffold (
        topBar = {
            TopAppBar(title = {
                Row {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Arrow Back",
                        modifier = Modifier.clickable { navController.popBackStack() })
                    Text(text = stringResource(id = R.string.log_txt))
                    Spacer(modifier = Modifier.width(8.dp))

                }
            })
        }){
        RegistrationBodyContent(navController, paramText)
    }
}
@Composable
fun RegistrationBodyContent(navController: NavController, paramText: String?){
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ){
        //TODO: meter un espacio por el scaffold
        typeBread()
        Text(text = stringResource(id = R.string.fourComponents))
        Text(text = stringResource(id = R.string.limit))
        topings()
        Spacer(modifier = Modifier.weight(1f))
        Row (
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.Bottom
        ){
            Button(onClick = { navController.navigate(route = AppScreens.SummaryScreen.route+ "/This is a param") }) {
                Text(text = stringResource(id = R.string.order))
            }
            Button(onClick = { /*Acer aparecer un dialog*/navController.navigate(route = AppScreens.ExitScreen.route+ "/This is a param")    }) {
                Text(text = stringResource(id = R.string.exit_txt))
            }
        }
    }
}

@Composable
fun typeBread(): Unit {
    val radioOptions = listOf(stringResource(id = R.string.bread01), stringResource(id = R.string.bread02), stringResource(id = R.string.bread03))
    var selectedRadioButton by remember { mutableStateOf<String?>(null) }

    radioOptions.forEach{option ->
        Row (
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .selectable(
                    selected = selectedRadioButton == option,
                    onClick = {
                        selectedRadioButton = option
                    }
                )
                .fillMaxWidth()
        ){
            RadioButton(
                selected = selectedRadioButton == option,
                onClick = {
                    selectedRadioButton = option
                },
                modifier = Modifier.padding(end = 8.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = option)
        }
    }
}
@Composable
fun topings(): Unit {
    val toppingStrings = listOf(
        R.string.lettuce,
        R.string.egg,
        R.string.cheese,
        R.string.bacon,
        R.string.ham,
        R.string.onion,
        R.string.tomato,
        R.string.gluten_free
    )
    val checkedStates = remember { mutableStateMapOf<Int, Boolean>() }
    for (toppingStringId in toppingStrings) {
        val toppingString = stringResource(id = toppingStringId)
        Row(
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Checkbox(
                checked = checkedStates[toppingStringId] ?: false,
                onCheckedChange = {
                    checkedStates[toppingStringId] = it
                },
                modifier = Modifier.padding(end = 8.dp)
            )
            Text(text = toppingString)
        }
    }
}
## Loging
![Alt text](image-2.png)

la idea es que si presionas en la imaguen la imaguen cambia

## Pedido
![Alt text](image-4.png)

Añadir para comer en restaurante o para llevar
Estaria be que ficara, tu pedido estara listo en h mas 30 min
## Resumen
![Alt text](image-5.png)

## Exit
![Alt text](image-6.png)

# TODO
1. [ ] Diseñar las ventanas
2. [ ] Asignar funciones a los botones
3. [ ] Que puedan compartir información
4. [ ] Comprobar los Strings harkodeados
5. [ ] Comprobar Colores harkodeados
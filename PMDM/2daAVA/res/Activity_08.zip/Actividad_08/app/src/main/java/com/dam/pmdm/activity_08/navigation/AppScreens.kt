package com.dam.pmdm.activity_08.navigation

sealed class AppScreens(val route: String){
    object FirstScreen: AppScreens("FirstScreen")
    object ScondScreen: AppScreens("SecondScreen")
}

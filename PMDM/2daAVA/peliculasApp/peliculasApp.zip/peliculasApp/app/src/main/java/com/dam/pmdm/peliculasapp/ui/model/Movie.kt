package com.dam.pmdm.peliculasapp.ui.model

data class Movie(
    val title : String,
    val director: String,
    val year: String
)

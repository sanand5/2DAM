package com.dam.pmdm.peliculasapp.util

object FireStoreCollections{
    const val MOVIE = "peliculas"
}
# Something for Practica Kotlin

### Menu
1. Añadir Producto
2. Mostrar todo
3. Mostrar por campo
   1. Mostrar por Nombre
   2. Mostrar por Tipo
   3. Mostrar por Precio
   4. Mostrar por ID
4. Filtrar
   1. Filtrar por ID
   2. Filtrar por Nombre
   2. Filtrar por Tipo
   3. Filtrar por Precio
      1. Mayor que...
      2. Menor que...
5. Calcular
   1. Sumatorio total
   2. Sumatorio por tipo

## TODO


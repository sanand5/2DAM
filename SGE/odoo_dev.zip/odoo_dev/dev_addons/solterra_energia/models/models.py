from odoo import models, fields, api
from odoo.exceptions import ValidationError
from odoo import _

class propietarios(models.Model):
    _name = 'solterra_energia.propietarios'
    _description = 'solterra_energia.propietarios'

    name = fields.Char(string='Nombre')
    apellidos = fields.Char(string='Apellidos')
    telefono = fields.Integer(string='Telefono')
    email = fields.Char(string='Email')
    casas = fields.One2many('solterra_energia.casas', 'propietario', string='Casa')
    
class casas(models.Model):
    _name = 'solterra_energia.casas'
    _description = 'solterra_energia.casas'

    ESTADOS = [
        ('por_hacer', 'Por hacer'),
        ('en_proceso', 'En proceso'),
        ('finalizada', 'Finalizada'),
    ]
    propietario = fields.Many2one('solterra_energia.propietarios', string='Propietario')
    direccion = fields.Char(string='Dirección')
    fecha_inicio = fields.Date(string='Fecha de inicio')
    fecha_final = fields.Date(string='Fecha final')
    estado = fields.Selection(ESTADOS, string='Estado', compute='_compute_estado')
    finalizada = fields.Boolean(string='Finalizada', default=False)
    tareas = fields.Many2many('solterra_energia.tareas', 'name', string='Tareas')
    
    @api.depends('finalizada', 'tareas')
    def _compute_estado(self):
        for casa in self:
            if casa.finalizada:
                casa.estado = 'finalizada'
            elif casa.tareas:
                casa.estado = 'en_proceso'
            else:
                casa.estado = 'por_hacer'

    
class tareas(models.Model):
    _name = 'solterra_energia.tareas'
    _description = 'solterra_energia.tareas'

    name = fields.Char(string='Nombre')
    descripcion = fields.Char(string='Descripción')

# -*- coding: utf-8 -*-
# from odoo import http


# class SolterraEnergia(http.Controller):
#     @http.route('/solterra_energia/solterra_energia', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/solterra_energia/solterra_energia/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('solterra_energia.listing', {
#             'root': '/solterra_energia/solterra_energia',
#             'objects': http.request.env['solterra_energia.solterra_energia'].search([]),
#         })

#     @http.route('/solterra_energia/solterra_energia/objects/<model("solterra_energia.solterra_energia"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('solterra_energia.object', {
#             'object': obj
#         })
